import { useState } from "react";
import { Hero } from "./components/Hero";
import { TargetAudience } from "./components/TargetAudience";
import { Problems } from "./components/Problems";
import { Services } from "./components/Services";
import { Process } from "./components/Process";
import { AuditBenefits } from "./components/AuditBenefits";
import { FAQ } from "./components/FAQ";
import { FinalCTA } from "./components/FinalCTA";
import { Footer } from "./components/Footer";
import { MobileMenu } from "./components/MobileMenu";

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="relative bg-[#0f0f34] min-h-screen w-full overflow-x-hidden">
      {/* Background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -left-[20%] top-[10%] w-[500px] h-[500px] bg-gradient-to-b from-[rgba(84,84,212,0.27)] to-[rgba(84,84,212,0.11)] rounded-full blur-[150px] rotate-[-52deg]" />
        <div className="absolute right-[-10%] top-[5%] w-[500px] h-[500px] bg-gradient-to-b from-[rgba(156,84,212,0.27)] to-[rgba(212,84,84,0.11)] rounded-full blur-[150px] rotate-45" />
        <div className="absolute left-[10%] bottom-[20%] w-[400px] h-[400px] bg-gradient-to-b from-[rgba(84,84,212,0.27)] to-[rgba(84,84,212,0.11)] rounded-full blur-[100px]" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        <Hero onMenuToggle={() => setMenuOpen(true)} />
        <TargetAudience />
        <Problems />
        <Services />
        <Process />
        <AuditBenefits />
        <FAQ />
        <FinalCTA />
        <Footer />
      </div>

      {/* Mobile Menu */}
      <MobileMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />
    </div>
  );
}
