export function TargetAudience() {
  const audiences = [
    "Производители промышленного оборудования",
    "Поставщики комплектующих",
    "Производственные компании, работающие под заказ",
    "Металлообработка / инженерные производства",
    "B2B-поставщики с длинным циклом сделки",
  ];

  return (
    <section className="relative py-16 md:py-24 px-5 md:px-20">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white text-center mb-4">
          Для кого наш подход
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-12">
          {audiences.map((audience, index) => (
            <div
              key={index}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#f61b2c]/20 via-[#ed1b8d]/20 to-[#ff7027]/20 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative p-6 bg-[#1a1a3e] border border-[#2d2d5a] rounded-xl hover:border-[#f61b2c]/50 transition-all">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#f61b2c] to-[#ed1b8d] flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z"/>
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="text-white text-base font-medium leading-snug">{audience}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <p className="text-center text-white/70 text-base md:text-lg mt-12 max-w-3xl mx-auto">
          Работаем с компаниями, у которых уже есть действующий бизнес и стоит задача роста через интернет рекламу.
        </p>
      </div>
    </section>
  );
}
