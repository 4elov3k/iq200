import imgLogo1 from "figma:asset/4a3ee834565eca061c366271f5bfe2c3585a1541.png";
import imgImage30 from "figma:asset/42d7cafdf85dbad55d237a834b669af3dcbc94ed.png";

interface HeroProps {
  onMenuToggle: () => void;
}

export function Hero({ onMenuToggle }: HeroProps) {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex flex-col">
      {/* Background image */}
      <div className="absolute inset-0 opacity-20">
        <img
          src={imgImage30}
          alt=""
          className="w-full h-full object-cover"
        />
      </div>

      {/* Header */}
      <header className="relative z-20 px-5 md:px-20 py-5 md:py-10 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-8 md:w-16 h-8 md:h-16 overflow-hidden flex-shrink-0">
            <img
              src={imgLogo1}
              alt="IQ 200"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="hidden md:block">
            <div className="text-white font-semibold text-lg md:text-2xl">
              IQ 200
            </div>
            <div className="text-white/80 text-xs uppercase tracking-wider">
              Digital-агентство полного цикла
            </div>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8 text-white text-sm">
          <button onClick={() => scrollToSection("services")} className="hover:text-[#f61b2c] transition-colors">
            Услуги
          </button>
          <button onClick={() => scrollToSection("process")} className="hover:text-[#f61b2c] transition-colors">
            Процесс
          </button>
          <button onClick={() => scrollToSection("faq")} className="hover:text-[#f61b2c] transition-colors">
            Вопросы
          </button>
          <button onClick={() => scrollToSection("contact")} className="hover:text-[#f61b2c] transition-colors">
            Контакты
          </button>
        </nav>

        {/* Contact Info */}
        <div className="hidden lg:flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#60D66A] to-[#20B038] flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
              </svg>
            </div>
            <div>
              <div className="text-white font-bold text-lg">+7 (909) 089 18 89</div>
              <div className="text-white/70 text-xs">Работаем с 8:00 до 20:00</div>
            </div>
          </div>
          <button 
            onClick={() => scrollToSection("contact")}
            className="px-6 py-2.5 border-2 border-[#f61b2c] text-white text-sm font-bold rounded-full hover:bg-[#f61b2c]/10 transition-all uppercase"
          >
            Заказать звонок
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={onMenuToggle}
          className="lg:hidden flex flex-col gap-1.5 p-2"
          aria-label="Menu"
        >
          <div className="w-5 h-0.5 bg-white rounded" />
          <div className="w-3.5 h-0.5 bg-white rounded ml-auto" />
          <div className="w-5 h-0.5 bg-white rounded" />
        </button>
      </header>

      {/* Hero Content */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-5 md:px-20 py-12 md:py-20 text-center">
        <div className="max-w-5xl mx-auto space-y-6 md:space-y-8">
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
            Привлекаем B2B-заявки для{" "}
            <span className="bg-gradient-to-r from-[#f61b2c] via-[#ed1b8d] to-[#ff7027] bg-clip-text text-transparent">
              производителей и поставщиков
            </span>{" "}
            промышленного оборудования
          </h1>

          <p className="text-base md:text-xl text-white/80 max-w-3xl mx-auto leading-relaxed">
            Помогаем производственным компаниям по России получать целевые обращения через сайт, SEO и рекламу без хаотичного маркетинга и пустых обещаний
          </p>

          {/* Key Points */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4 text-left max-w-3xl mx-auto text-sm md:text-base">
            <div className="flex items-start gap-2 text-white/90">
              <svg className="w-5 h-5 text-[#f61b2c] flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span>работаем с B2B и производством по всей России</span>
            </div>
            <div className="flex items-start gap-2 text-white/90">
              <svg className="w-5 h-5 text-[#f61b2c] flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span>разрабатываем и настраиваем сайты, SEO, Яндекс.Директ</span>
            </div>
            <div className="flex items-start gap-2 text-white/90">
              <svg className="w-5 h-5 text-[#f61b2c] flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span>понимаем длинный цикл сделки и сложный продукт</span>
            </div>
            <div className="flex items-start gap-2 text-white/90">
              <svg className="w-5 h-5 text-[#f61b2c] flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span>фокусируемся на заявках и запросах КП</span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
            <button
              onClick={() => scrollToSection("contact")}
              className="relative group w-full sm:w-auto"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#f61b2c] via-[#ed1b8d] to-[#ff7027] rounded-full blur-lg opacity-50 group-hover:opacity-75 transition-opacity" />
              <div className="relative px-8 py-4 bg-gradient-to-r from-[#f61b2c] via-[#ed1b8d] to-[#ff7027] rounded-full text-white font-bold text-sm md:text-base uppercase tracking-wide">
                Получить аудит сайта и рекламы
              </div>
            </button>
            <button
              onClick={() => scrollToSection("services")}
              className="px-8 py-4 border-2 border-white/30 text-white text-sm md:text-base font-semibold rounded-full hover:border-white/50 hover:bg-white/5 transition-all w-full sm:w-auto"
            >
              Посмотреть услуги
            </button>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="relative z-10 px-5 md:px-20 pb-12 md:pb-20">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          <div className="text-center">
            <div className="text-3xl md:text-5xl font-light text-white mb-2">14</div>
            <div className="text-sm md:text-base text-white/70">Лет на рынке</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-5xl font-light text-white mb-2">250+</div>
            <div className="text-sm md:text-base text-white/70">Производственных клиентов</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-5xl font-light text-white mb-2">
              <span>80</span>
              <span className="text-xl md:text-2xl font-medium"> млн.</span>
            </div>
            <div className="text-sm md:text-base text-white/70">Бюджет рекламы в год</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-5xl font-light text-white mb-2">35</div>
            <div className="text-sm md:text-base text-white/70">Специалистов в команде</div>
          </div>
        </div>
      </div>
    </section>
  );
}
