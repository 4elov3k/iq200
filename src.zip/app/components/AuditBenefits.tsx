export function AuditBenefits() {
  const benefits = [
    "Краткий разбор сайта с точки зрения B2B-продаж",
    "Оценка структуры под SEO и коммерческие запросы",
    "Оценка текущей рекламы, если она уже есть",
    "3–5 точек роста",
    "Рекомендации, с чего начать в первую очередь",
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative py-16 md:py-24 px-5 md:px-20">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
            Что входит в первичный аудит
          </h2>
          <p className="text-white/70 text-lg max-w-2xl mx-auto">
            Вместо общих слов мы проведём конкретный анализ вашего сайта и рекламы
          </p>
        </div>

        <div className="bg-[#1a1a3e] border border-[#2d2d5a] rounded-2xl p-8 md:p-12">
          <div className="space-y-5">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#f61b2c] to-[#ed1b8d] flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="text-white text-lg leading-relaxed pt-0.5">{benefit}</p>
              </div>
            ))}
          </div>

          <div className="mt-10 flex justify-center">
            <button
              onClick={scrollToContact}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#f61b2c] via-[#ed1b8d] to-[#ff7027] rounded-full blur-lg opacity-50 group-hover:opacity-75 transition-opacity" />
              <div className="relative px-10 py-5 bg-gradient-to-r from-[#f61b2c] via-[#ed1b8d] to-[#ff7027] rounded-full text-white font-bold text-base uppercase tracking-wide">
                Получить аудит бесплатно
              </div>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
