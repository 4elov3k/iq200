export function Services() {
  const services = [
    {
      title: "Разработка и переработка сайта",
      description: "Корпоративные сайты, каталоги, интернет-магазины, усиление структуры и доверия.",
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
    },
    {
      title: "SEO-продвижение",
      description: "Рост поискового трафика и обращений по целевым B2B-запросам.",
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      ),
    },
    {
      title: "Яндекс.Директ",
      description: "Настройка и ведение рекламы с фокусом на целевые заявки, а не просто клики.",
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
        </svg>
      ),
    },
    {
      title: "Интеграции и доработки",
      description: "Формы, каталоги, синхронизация с CRM / 1С, улучшение функционала.",
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
    },
    {
      title: "Комплексный digital-подход",
      description: "Когда нужен не один инструмент, а система: сайт + SEO + реклама.",
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      ),
    },
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="services" className="relative py-16 md:py-24 px-5 md:px-20">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white text-center mb-4">
          Что мы делаем для{" "}
          <span className="bg-gradient-to-r from-[#f61b2c] via-[#ed1b8d] to-[#ff7027] bg-clip-text text-transparent">
            производственных B2B-компаний
          </span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {services.map((service, index) => (
            <div
              key={index}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-[#f61b2c]/10 via-[#ed1b8d]/10 to-[#ff7027]/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative p-6 md:p-8 bg-[#1a1a3e] border border-[#2d2d5a] rounded-2xl hover:border-[#f61b2c]/50 transition-all h-full flex flex-col">
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#f61b2c] to-[#ed1b8d] flex items-center justify-center text-white mb-6">
                  {service.icon}
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                <p className="text-white/70 text-base leading-relaxed flex-1">{service.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-center mt-12">
          <button
            onClick={scrollToContact}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#f61b2c] via-[#ed1b8d] to-[#ff7027] rounded-full blur-lg opacity-50 group-hover:opacity-75 transition-opacity" />
            <div className="relative px-8 py-4 bg-gradient-to-r from-[#f61b2c] via-[#ed1b8d] to-[#ff7027] rounded-full text-white font-bold text-sm md:text-base uppercase tracking-wide">
              Запросить разбор под нашу задачу
            </div>
          </button>
        </div>
      </div>
    </section>
  );
}
